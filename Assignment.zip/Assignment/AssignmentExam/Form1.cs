﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AssignmentExam
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            AppSetUp();
        }
        private void AppSetUp()
        {
            dateTimePicker1.MinDate = new DateTime(2020, 2, 3);
            dateTimePicker1.MaxDate = new DateTime(2020, 2, 10);

            txtFirst.Text = Constants.FirstNameWaterMark;
            txtLast.Text = Constants.LastNameWaterMark;
        }
        
        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void radioButton1_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void radioButton2_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void dateTimePicker1_ValueChanged(object sender, EventArgs e)
        {

        }
       

        private void txtLast_TextChanged(object sender, EventArgs e)
        {
            if (!System.Text.RegularExpressions.Regex.IsMatch(txtLast.Text, Constants.Regex))
            {
                if (txtLast.Text.Length > 0)
                {
                    txtLast.Text = txtLast.Text.Remove(txtLast.Text.Length - 1);
                    txtLast.SelectionStart = txtLast.Text.Length;
                    txtLast.SelectionLength = 0;
                }
            }
        }
        private void txtLast_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (txtLast.Text == Constants.LastNameWaterMark)
            {
                txtLast.Text = "";
            }
        }

        private void txtLast_KeyUp(object sender, KeyEventArgs e)
        {
            if (txtLast.Text == "")
                txtLast.Text = Constants.LastNameWaterMark;
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            if (CheckIfDataValid())
            {

                // To Do Save functionality

                MessageBox.Show("Successfully Saved");
            }
        }

        private bool CheckIfDataValid()
        {
            if (txtFirst.Text == "" || txtFirst.Text == Constants.FirstNameWaterMark)
            {
                return false;
            }

            if (txtLast.Text == "" || txtLast.Text == Constants.LastNameWaterMark)
            {
                return false;
            }

            return true;
        }

        private void txtFirst_TextChanged_1(object sender, EventArgs e)
        {
            if (!System.Text.RegularExpressions.Regex.IsMatch(txtFirst.Text, Constants.Regex))
            {
                if (txtFirst.Text.Length > 0)
                {
                    txtFirst.Text = txtFirst.Text.Remove(txtFirst.Text.Length - 1);
                    txtFirst.SelectionStart = txtFirst.Text.Length;
                    txtFirst.SelectionLength = 0;
                }
            }
        }

        private void txtFirst_KeyPress_1(object sender, KeyPressEventArgs e)
        {
            if (txtFirst.Text == Constants.FirstNameWaterMark)
            {
                txtFirst.Text = "";
            }
        }

        private void txtFirst_KeyUp_1(object sender, KeyEventArgs e)
        {
            if (txtFirst.Text == "")
                txtFirst.Text = Constants.FirstNameWaterMark;
        }

        private void btnRed_Click(object sender, EventArgs e)
        {
            txtFirst.Parent.BackColor = Color.OrangeRed;
        }

        private void btnDark_Click(object sender, EventArgs e)
        {
            txtFirst.Parent.BackColor = Color.Gray ;
        }

        private void btnLight_Click(object sender, EventArgs e)
        {
            txtFirst.Parent.BackColor = Color.White;
        }
    }
}
