﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AssignmentExam
{
    public static class Constants
    {
        public const string FirstNameWaterMark = "enter your first name";
        public const string LastNameWaterMark = "enter your last name";
        public const string Regex = "^[A-Za-z0-9 _]*[A-Za-z0-9][A-Za-z0-9 _]*$";
    }
}
